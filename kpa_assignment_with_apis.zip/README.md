# KPA Assignment - Backend (FastAPI)

## Setup Instructions

1. Create a virtual environment and activate it.
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Rename `.env.example` to `.env` and update DB credentials.
4. Run the server:
```bash
uvicorn app.main:app --reload
```

## Implemented APIs

### ✅ `POST /form-data/submit`
Submit form data:
```json
{
  "name": "Ahsan",
  "email": "ahsan@example.com",
  "phone": "9876543210"
}
```

### ✅ `GET /form-data/list`
Get all submitted form data

## Tech Stack

- FastAPI, PostgreSQL, SQLAlchemy, Pydantic

## Notes

- Connected to PostgreSQL using SQLAlchemy ORM.
- Modular structure for easy scaling.
