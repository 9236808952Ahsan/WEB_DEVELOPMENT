from sqlalchemy.orm import Session
from app import models, schemas

def create_form_data(db: Session, form: schemas.FormDataCreate):
    db_form = models.FormData(**form.dict())
    db.add(db_form)
    db.commit()
    db.refresh(db_form)
    return db_form

def get_all_form_data(db: Session):
    return db.query(models.FormData).all()
