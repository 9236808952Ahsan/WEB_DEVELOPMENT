from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.schemas import FormDataCreate, FormDataOut
from app.crud import create_form_data, get_all_form_data
from app.database import SessionLocal

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/submit", response_model=FormDataOut)
def submit_form(form: FormDataCreate, db: Session = Depends(get_db)):
    return create_form_data(db, form)

@router.get("/list", response_model=list[FormDataOut])
def list_forms(db: Session = Depends(get_db)):
    return get_all_form_data(db)
