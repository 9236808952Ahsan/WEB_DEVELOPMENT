from pydantic import BaseModel

class FormDataCreate(BaseModel):
    name: str
    email: str
    phone: str

class FormDataOut(FormDataCreate):
    id: int

    class Config:
        orm_mode = True
