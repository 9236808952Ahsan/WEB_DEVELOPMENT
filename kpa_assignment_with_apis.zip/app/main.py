from fastapi import FastAPI
from app import models, database
from app.routes import form_data
from app.database import engine

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

app.include_router(form_data.router, prefix="/form-data", tags=["Form Data"])

@app.get("/")
def root():
    return {"message": "KPA Assignment API Running!"}
